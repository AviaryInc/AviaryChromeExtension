(AV['stickerPacks'] || (AV['stickerPacks'] = [])).push(

    [
        "http://feather.aviary.com/stickers/400x400/red_arrow.png",
        "http://feather.aviary.com/stickers/100x100/red_arrow.png",
        "http://feather.aviary.com/stickers/1000x1000/red_arrow.png"
    ],
    [
        "http://feather.aviary.com/stickers/400x400/blue_arrow.png",
        "http://feather.aviary.com/stickers/100x100/blue_arrow.png",
        "http://feather.aviary.com/stickers/1000x1000/blue_arrow.png"
    ],
    [
        "http://feather.aviary.com/stickers/400x400/green_circle.png",
        "http://feather.aviary.com/stickers/100x100/green_circle.png",
        "http://feather.aviary.com/stickers/1000x1000/green_circle.png"
    ],
    [
        "http://feather.aviary.com/stickers/400x400/orange_square.png",
        "http://feather.aviary.com/stickers/100x100/orange_square.png",
        "http://feather.aviary.com/stickers/1000x1000/orange_square.png"
    ]

);
