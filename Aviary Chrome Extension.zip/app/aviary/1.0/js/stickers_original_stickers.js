(AV['stickerPacks'] || (AV['stickerPacks'] = [])).push(

    [
        AV.build['feather_stickerURL'] + "400x400/sombrero.png",
        AV.build['feather_stickerURL'] + "100x100/sombrero.png",
        AV.build['feather_stickerURL'] + "1000x1000/sombrero.png"
    ],
    [
        AV.build['feather_stickerURL'] + "400x400/helicopter.png",
        AV.build['feather_stickerURL'] + "100x100/helicopter.png",
        AV.build['feather_stickerURL'] + "1000x1000/helicopter.png"
    ],
    [
        AV.build['feather_stickerURL'] + "400x400/crown.png",
        AV.build['feather_stickerURL'] + "100x100/crown.png",
        AV.build['feather_stickerURL'] + "1000x1000/crown.png"
    ],
    [
        AV.build['feather_stickerURL'] + "400x400/fez.png",
        AV.build['feather_stickerURL'] + "100x100/fez.png",
        AV.build['feather_stickerURL'] + "1000x1000/fez.png"
    ],
    [
        AV.build['feather_stickerURL'] + "400x400/3d_glasses.png",
        AV.build['feather_stickerURL'] + "100x100/3d_glasses.png",
        AV.build['feather_stickerURL'] + "1000x1000/3d_glasses.png"
    ],
    [
        AV.build['feather_stickerURL'] + "400x400/hipster_glasses.png",
        AV.build['feather_stickerURL'] + "100x100/hipster_glasses.png",
        AV.build['feather_stickerURL'] + "1000x1000/hipster_glasses.png"
    ],
    [
        AV.build['feather_stickerURL'] + "400x400/disguise.png",
        AV.build['feather_stickerURL'] + "100x100/disguise.png",
        AV.build['feather_stickerURL'] + "1000x1000/disguise.png"
    ],
    [
        AV.build['feather_stickerURL'] + "400x400/aviators.png",
        AV.build['feather_stickerURL'] + "100x100/aviators.png",
        AV.build['feather_stickerURL'] + "1000x1000/aviators.png"
    ],
    [
        AV.build['feather_stickerURL'] + "400x400/eyepatch.png",
        AV.build['feather_stickerURL'] + "100x100/eyepatch.png",
        AV.build['feather_stickerURL'] + "1000x1000/eyepatch.png"
    ],
    [
        AV.build['feather_stickerURL'] + "400x400/bow_tie.png",
        AV.build['feather_stickerURL'] + "100x100/bow_tie.png",
        AV.build['feather_stickerURL'] + "1000x1000/bow_tie.png"
    ],
    [
        AV.build['feather_stickerURL'] + "400x400/tie.png",
        AV.build['feather_stickerURL'] + "100x100/tie.png",
        AV.build['feather_stickerURL'] + "1000x1000/tie.png"
    ],
    [
        AV.build['feather_stickerURL'] + "400x400/pipe.png",
        AV.build['feather_stickerURL'] + "100x100/pipe.png",
        AV.build['feather_stickerURL'] + "1000x1000/pipe.png"
    ],
    [
        AV.build['feather_stickerURL'] + "400x400/cigar.png",
        AV.build['feather_stickerURL'] + "100x100/cigar.png",
        AV.build['feather_stickerURL'] + "1000x1000/cigar.png"
    ],
    [
        AV.build['feather_stickerURL'] + "400x400/arrow.png",
        AV.build['feather_stickerURL'] + "100x100/arrow.png",
        AV.build['feather_stickerURL'] + "1000x1000/arrow.png"
    ],
    [
        AV.build['feather_stickerURL'] + "400x400/green_bubble.png",
        AV.build['feather_stickerURL'] + "100x100/green_bubble.png",
        AV.build['feather_stickerURL'] + "1000x1000/green_bubble.png"
    ],
    [
        AV.build['feather_stickerURL'] + "400x400/orange_bubble.png",
        AV.build['feather_stickerURL'] + "100x100/orange_bubble.png",
        AV.build['feather_stickerURL'] + "1000x1000/orange_bubble.png"
    ],
    [
        AV.build['feather_stickerURL'] + "400x400/blue_bubble.png",
        AV.build['feather_stickerURL'] + "100x100/blue_bubble.png",
        AV.build['feather_stickerURL'] + "1000x1000/blue_bubble.png"
    ],
    [
        AV.build['feather_stickerURL'] + "400x400/pink_bubble.png",
        AV.build['feather_stickerURL'] + "100x100/pink_bubble.png",
        AV.build['feather_stickerURL'] + "1000x1000/pink_bubble.png"
    ],
    [
        AV.build['feather_stickerURL'] + "400x400/star.png",
        AV.build['feather_stickerURL'] + "100x100/star.png",
        AV.build['feather_stickerURL'] + "1000x1000/star.png"
    ],
    [
        AV.build['feather_stickerURL'] + "400x400/heart.png",
        AV.build['feather_stickerURL'] + "100x100/heart.png",
        AV.build['feather_stickerURL'] + "1000x1000/heart.png"
    ],
    [
        AV.build['feather_stickerURL'] + "400x400/red_arrow.png",
        AV.build['feather_stickerURL'] + "100x100/red_arrow.png",
        AV.build['feather_stickerURL'] + "1000x1000/red_arrow.png"
    ],
    [
        AV.build['feather_stickerURL'] + "400x400/blue_arrow.png",
        AV.build['feather_stickerURL'] + "100x100/blue_arrow.png",
        AV.build['feather_stickerURL'] + "1000x1000/blue_arrow.png"
    ],
    [
        AV.build['feather_stickerURL'] + "400x400/double_arrow.png",
        AV.build['feather_stickerURL'] + "100x100/double_arrow.png",
        AV.build['feather_stickerURL'] + "1000x1000/double_arrow.png"
    ],
    [
        AV.build['feather_stickerURL'] + "400x400/green_circle.png",
        AV.build['feather_stickerURL'] + "100x100/green_circle.png",
        AV.build['feather_stickerURL'] + "1000x1000/green_circle.png"
    ],
    [
        AV.build['feather_stickerURL'] + "400x400/orange_square.png",
        AV.build['feather_stickerURL'] + "100x100/orange_square.png",
        AV.build['feather_stickerURL'] + "1000x1000/orange_square.png"
    ]

);
