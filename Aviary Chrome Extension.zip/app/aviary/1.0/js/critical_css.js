(function(AV) {
AV.criticalLayoutStyles ='
#avpw_holder{border:0;margin:0;padding:0;}
#avpw_controls{overflow:hidden;z-index:9999;min-height:396px;min-width:735px;}
.avpw_is_fullscreen #avpw_controls{position:fixed;top:8%;left:10%;right:10%;bottom:7.3%;}
.avpw_is_embed #avpw_controls{position:absolute;top:1px;left:1px;right:1px;bottom:1px;}
';
})(AV = window['AV'] || {});
